package wikiPediaTesting;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import lib.ExcelDataConfig;

public class TC1_WikiPediaRegisterExcelData

	{
	WebDriver driver;
	
	@BeforeMethod
	public void aplicationSetup()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\stepanyuk\\Eclips_Libs\\chromedriver_win32\\chromedriver.exe");  
		driver=new ChromeDriver();
		driver.get("https://uk.wikipedia.org/w/index.php?title=%D0%A1%D0%BF%D0%B5%D1%86%D1%96%D0%B0%D0%BB%D1%8C%D0%BD%D0%B0:%D0%A1%D1%82%D0%B2%D0%BE%D1%80%D0%B8%D1%82%D0%B8_%D0%BE%D0%B1%D0%BB%D1%96%D0%BA%D0%BE%D0%B2%D0%B8%D0%B9_%D0%B7%D0%B0%D0%BF%D0%B8%D1%81&returnto=%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0+%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}
	
	@Test(dataProvider="registerData")
	public void WikiPediaRegister(String name, String password, String retypePassword, String email) throws InterruptedException
	{
		driver.findElement(By.id("wpName2")).sendKeys(name);
		driver.findElement(By.id("wpPassword2")).sendKeys(password);
		driver.findElement(By.id("wpRetype")).sendKeys(retypePassword);
		driver.findElement(By.id("wpEmail")).sendKeys(email);
		
		Thread.sleep(5000);
		System.out.println("You have 35 seconds to enter CAPTCHA or Test will fail");
		Thread.sleep(35000);
		
		driver.findElement(By.xpath("//*[@id=\"wpCreateaccount\"]")).click();
		Thread.sleep(5000);
		
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id=\"mw-gettingstarted-cta-other-page\"]")).getText().contains("��������� ������������"));
				
		System.out.println("Register has been completed successfully");
	}
	
	@AfterMethod
	public void tearDown()
	{
		driver.close();	
	}
			
	@DataProvider(name="registerData")
	public Object[][] passData()
	{
		ExcelDataConfig config=new ExcelDataConfig("C:\\Users\\stepanyuk\\eclipse-workspace\\WikipediaMavenCaptcha\\TestData\\InputTestDataWikiRegister.xlsx");
		
		int rows=config.getRowCount(0);
		// 0-because it is the first sheet in Excel file
				
		Object[][] data=new Object[rows][4];
		
		for(int i=0;i<rows;i++)
			
		{
			
		data[i][0]=config.getData(0, i, 1);
		// (0, i, 1) - 0-sheet of Excel, i-row of Excel, 1-column of Excel
		
		data[i][1]=config.getData(0, i, 2);
		data[i][2]=config.getData(0, i, 3);
		data[i][3]=config.getData(0, i, 4);
		
		}
				
		return data;
		
	}
	}
	
	
