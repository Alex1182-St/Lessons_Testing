package wikiPediaTesting;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import lib.ExcelDataConfig;

public class TC2_WikiPediaLoginExcelData

	{
	WebDriver driver;
	
	@BeforeMethod
	public void aplicationSetup()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\stepanyuk\\Eclips_Libs\\chromedriver_win32\\chromedriver.exe");  
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://uk.wikipedia.org/w/index.php?title=%D0%A1%D0%BF%D0%B5%D1%86%D1%96%D0%B0%D0%BB%D1%8C%D0%BD%D0%B0:%D0%92%D1%85%D1%96%D0%B4&returnto=%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0+%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}
		
	@Test(dataProvider="loginData")
	public void LeanTestingRegister(String yourusername, String password) throws InterruptedException
	{
		driver.findElement(By.id("wpName1")).sendKeys(yourusername);
		driver.findElement(By.id("wpPassword1")).sendKeys(password);
		
		driver.findElement(By.xpath("//*[@id=\"wpRemember\"]")).click();
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//*[@id=\"wpLoginAttempt\"]")).click();
		Thread.sleep(5000);
		
		Assert.assertEquals("https://uk.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%B0_%D1%81%D1%82%D0%BE%D1%80%D1%96%D0%BD%D0%BA%D0%B0", driver.getCurrentUrl());
		System.out.println("LogIn is completed");
	}
	
	@AfterMethod
	public void tearDown()
	{
		driver.close();	
	}
	
			
	@DataProvider(name="loginData")
	public Object[][] passData()
	{
		ExcelDataConfig config=new ExcelDataConfig("C:\\Users\\stepanyuk\\eclipse-workspace\\WikipediaMavenCaptcha\\TestData\\InputTestDataWikiLogin.xlsx");
		
		int rows=config.getRowCount(0);
		// 0-because it is the first sheet in Excel file
				
		Object[][] data=new Object[rows][2];
		
		for(int i=0;i<rows;i++)
			
		{
			
		data[i][0]=config.getData(0, i, 1);
		// (0, i, 1) - 0-sheet of Excel, i-row of Excel, 1-column of Excel
		
		data[i][1]=config.getData(0, i, 2);
				
		}
				
		return data;
		
	}
	}
	
	
