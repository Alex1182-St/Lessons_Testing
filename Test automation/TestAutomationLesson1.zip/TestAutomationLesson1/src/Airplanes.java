public class Airplanes
{
    String typeOfAirplane;
    String nameOfProducer;
    int quantity;
    int passangersCapacity;
    float cargoWeightCapacity;
    float cargoVolumeCapacity;
    float ticketsPrice;
    boolean isRefuel;

    void startRefuel() {
    }

    void startCargoLoading() {
    }

    void startPassangersLoading() {
    }

    void startAirplaneTakeoff() {
    }

    void flying() {
    }

    void startAirplaneLanding() {
    }

}
