public class AlcoholicDrinks
{
    String typeOfDrink;
    String nameOfProducer;
    String strengthOfDrink;
    String typeOfPackaging;
    int bottleQuantity;
    float bottleVolume;
    float price;
    boolean isFrozen;

    void moveToFreezer() {
    }

    void startBottleOpening() {
    }

    void startDrinkPour() {
    }

    void drinking() {
    }

}
