public class Food
{
    String typeOfFood;
    int quantity;
    float weight;
    float price;
    boolean isFresh;
    boolean isFrozen;
    boolean isWashed;

    void startWashing() {
    }

    void moveToFreezer() {
    }

    void moveToDishes() {
    }

    void startEating() {
    }

    void startCutting() {
    }

    void startCooking() {
    }

}
