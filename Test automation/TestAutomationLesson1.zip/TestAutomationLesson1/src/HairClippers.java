public class HairClippers
{
    String markOfHairClipper;
    int quantity;
    int electricityConsumption;
    int wireLength;
    boolean hasReplacebleCutters;

    void startHairCutting() {
    }

    void startCuttersCleaning() {
    }

    void changeCutterType() {
    }

}
