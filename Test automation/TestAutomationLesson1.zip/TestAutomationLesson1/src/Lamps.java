public class Lamps
{
    String nameOfProducer;
    String typeOfLamp;
    int quantity;
    int lightTemperature;
    int lightbuldPower;
    String lightbulbType;

    void turnLightOn() {
    }

    void turnLightOff() {
    }

    void replaceLightbulb() {
    }
}