public class MobilePhones
{
    String nameOfMobilePhone;
    String nameOfPhoneOS;
    String nameOfProcessor;
    float phoneDisplaySize;
    int weight;
    float price;
    boolean is4GSupport;
    boolean isGPSSupport;
    int PhotoCameraPixels;
    int batteryCapacity;

    void startCalling() {
    }

    void startBatteryCharging() {
    }

    void startWebSurfing() {
    }

    void makingPhotography() {
    }

    void creatingVideo() {
    }

    void Gaming() {
    }

}
