public class PersonalComputers
{
    String nameOfProcessor;
    int processorCoresQuantity;
    int processorFrequency;
    String nameOfOS;
    int memoryRAMVolume;
    String nameOfVideoCard;
    int videoCardMemoryVolume;
    int powerOfPowerSupply;

    void startBIOSloading() {
    }

    void startOSloading() {
    }

    void startProgramExecution() {
    }

}
