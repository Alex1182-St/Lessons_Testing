public class SnowClearingMachine
{
    String typeOfChassis;
    String nameOfProducer;
    int quantity;
    int enginePower;
    float fuelConsumption;
    boolean isRefuel;

    void startRefuel() {
    }

    void startSnowCleaning() {
    }

    void startEngineMaintenance() {
    }
}
