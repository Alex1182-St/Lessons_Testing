public class UnmannedAerialVehicle
{
    String typeOfUAV;
    String nameOfUAV;
    int quantity;
    float maxCargoWeight;
    String typeOfEngine;
    String maxTimeOfFlying;
    int maxHeightOfFlying;
    int maxFlyingSpeed;
    boolean IsCamera;


    void startUAVTakeoff() {
    }

    void increaseFlyingSpeed() {
    }

    void executeAutomaticReturning() {
    }

    void startUAVVideoCamera() {
    }

    void startUAVLanding() {
    }

}
