public class Wardrobes
{
    int quantity;
    float height;
    float width;
    float depth;
    String typeOfMaterial;
    String typeOfDoors;

    void openTheDoor() {
    }

    void putClothesOnShelf() {

    }

    void hideInTheWardrobe() {

    }

    void closeTheDoor() {

    }

}
